Pagination
=========

A mobile-friendly pagination component, that can be easily customized using CSS or Sass.

[Article on CodyHouse](http://codyhouse.co/gem/css-pagination/)

[Demo](http://codyhouse.co/demo/pagination/index.html)
 
[Terms](http://codyhouse.co/terms/)
